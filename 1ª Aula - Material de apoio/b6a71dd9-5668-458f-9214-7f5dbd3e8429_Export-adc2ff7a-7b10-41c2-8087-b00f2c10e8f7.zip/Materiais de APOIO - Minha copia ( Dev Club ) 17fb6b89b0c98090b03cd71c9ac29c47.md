# Materiais de APOIO - Minha copia   
( Dev Club )

[HTML](https://www.notion.so/HTML-17fb6b89b0c981f2b5fbd7019a2c07f9?pvs=21)

[CSS](https://www.notion.so/CSS-17fb6b89b0c981f59a25d8c5a105e438?pvs=21)

[Git e Github](https://www.notion.so/Git-e-Github-17fb6b89b0c981e68d05c57cdd217f28?pvs=21)

[JavaScript](https://www.notion.so/JavaScript-17fb6b89b0c981959dbff943a4334c51?pvs=21)

[TypeScript](https://www.notion.so/TypeScript-17fb6b89b0c98189a5b0eb804a9d5b7f?pvs=21)

[Node.js - Em construção](https://www.notion.so/Node-js-Em-constru-o-17fb6b89b0c981228ec3d4125ffdb824?pvs=21)

[React](https://www.notion.so/React-17fb6b89b0c981fb9e43ce187b5cbd69?pvs=21)

[CodeMaster](https://www.notion.so/CodeMaster-17fb6b89b0c9816c8779d4f559dedd51?pvs=21)

[DevClub Pass](https://www.notion.so/DevClub-Pass-17fb6b89b0c981a78b0ec2e053af5317?pvs=21)